const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const User = require('./model/User');
const { check, validationResult } = require('express-validator');
var path = require('path');


app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.resolve(__dirname, 'Public')));



require('dotenv').config();
app.use(bodyParser.json());

app.get('/',(req,res)=>{
	res.sendFile('index.html',{root:__dirname});
});

app.post('/SignUp',[
	check('email').isEmail(),
	check('mobile').isLength({ min:10 })
],(req,res)=>{

	const errors = validationResult(req);
    if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
	console.log(req.body);
	const userData = new User(req.body).save();
	res.send(req.body);
});


app.get('/Show',async (req, res) => {
 const user = await User.find({});
    res.send(user);
});


mongoose.connect(process.env.MONGOD_URL,{ useUnifiedTopology: true, useNewUrlParser: true}).then(() => console.log('mongodb is connected'));
mongoose.Promise = global.Promise;


app.listen(process.env.PORT, () => {
console.log('Server running on port'+process.env.PORT);
});