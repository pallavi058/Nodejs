 const express = require('express');
 const app = express();
 const { check } = require('express-validator/check');

 app.use(express.json())

const logger = function (req, res, next) {
  // console.log('Middleware is used first time');
  if(req.body.name=='Rishi')
  {
  next();
  }
  else{
      console.log("Pallavi");
    res.send("pallavi")
   }

}
app.post('/form', [
  check('name').isLength({ min: 4 }),
check('email').custom(email => {
    if (alreadyHaveEmail(email)) {
      throw new Error('Email already registered')
    }
  }),
  check('age').isNumeric()
],(req, res) => {
  const name  = req.body.name
  const email = req.body.email
  const age   = req.body.age
  console.log('qsw =' +req.body.name);
})





app.listen(8888, console.log("8888"));

