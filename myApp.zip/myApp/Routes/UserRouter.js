const router = require("express").Router();
const mongoose = require("mongoose");
const User = mongoose.model("User");
const controller = require('../Controller/Usercontrol');


router.get("/fetchSingleUser/:id",async (req, res, next) =>{  // single id searching
    console.log(req.params.id);
    controller.search(req.params.id).then((success) =>{
        res.send(success);
    }).catch((err) => next(err))
   
});

router.put("/updateUser/:id",async (req, res,next) =>{  // updating 
    console.log(req.params.id);
    controller.updatedoc(req.params.id, req.body).then((correct)=>{ //here correct is variable anything can be considered
        res.send(correct);
    }).catch((err)=>next(err))
});

router.delete("/deleteUser/:id", async(req, res, next) =>{   //for deleting
    console.log(req.params.id);
    controller.deletedoc(req.params.id).then((right)=>{
        res.send(right);
    }).catch((err)=> next(err))
});
   
   

//without controller code 
/* router.put("/update/:id",async (req, res) =>{  // updating 
    console.log(req.params.id);
    const idno = await User.findOneAndUpdate({"_id" : req.params.id}, req.body,
    { new: true, runValidators: true});
    res.send(idno);
});

router.delete("/delete/:id", async(req, res) =>{
    console.log(req.params.id);
    const idno = await User.findByIdAndRemove({"_id":req.params.id})
}); */
router.post('/signUp', (req, res, next) =>{ //create data register
      
    controller.register(req.body).then((pallavi) => {
        res.send(pallavi);
    }).catch((err) => next(err))
    
});

router.get('/show',async (req, res) => { //display information
 const user =await User.find({});
    res.send(user);
});


router.post('/login', async (req,res,next) => { //for finding data.
    const email = req.body.email;
    const password = req.body.password; 
    controller.loginId(req.body.email, req.body.password).then((successful) =>{
        res.send(successful);
    }).catch((err)=> next(err))
});
   
   //verification of tokens

 function verifyToken(req, res, next){
     //Get auth header value
     const bearerHeader = req.headers['authorization'];
     //check if bearer is undefined
     console.log(bearerHeader);
   if(typeof bearerHeader!==undefined){
        // Split at the space
    const bearer = bearerHeader.split(' ');
      // Get token from array
      const bearerToken = bearer[1];
      // Set the token
      req.token = bearerToken;
      // Next middleware
      next();
    console.log(bearerHeader);
    }else{
    //Forbidden
    res.sendStatus(403); 
     }
}

module.exports = router;