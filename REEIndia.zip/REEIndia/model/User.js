const mongoose = require('mongoose');


const UserSchema = new mongoose.Schema({
    name:{
         type: String,
         required:"Your Full name is required"
     },

    email:{
        type : String
     },
    mobile:{
        type:String,
        required:"Mobile no is required"
    },
    message:{
        type:String
    }

  } ,  {
    timestamps:true
     }
);


module.exports = mongoose.model("User", UserSchema);
