const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    firstName:{
        type: String,
     },
     lastName:{
         type: String,
     },
     email:{
         type:String,
         required: "EmailId is required"
     },
     password:{
         type: String,
         required: "Password is required"
     }
} , {
    timestamps:true
    }
);

module.exports = mongoose.model("User", UserSchema)