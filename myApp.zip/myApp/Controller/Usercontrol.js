const mongoose = require("mongoose");
const User = mongoose.model("User");
 const jwt = require("jsonwebtoken");

 module.exports.register = (userInfo) => {
    return new Promise((resolve, reject) =>{
        const userData = new User(userInfo).save().then((r) => resolve(r)).catch((err)=>reject('Something is wrong'));; //for saving data
    });
}

module.exports.search = (id1) =>{
    return new Promise((resolve, reject) =>{
        User.findOne({ _id: id1}).then((fetchUser) => resolve(fetchUser)).catch((err) => reject('Something is incorrect'));
   
    });
}

module.exports.deletedoc = (id2) =>{
    return new Promise((resolve, reject)=>{
     User.findByIdAndRemove({_id:id2}).then((deleteUser) => resolve(deleteUser)).catch((err)=>reject('Deletion is failed'));
    });
}

module.exports.updatedoc = (id3, body1) =>{
    return new Promise((resolve, reject) =>{
        User.findOneAndUpdate({_id :id3}, body1,
    {new:true, runValidators: true}).then((updatedoc)=> resolve(updatedoc)).catch((err)=>reject('Updation becomes failed'));
    });
}//new :true ,new is used for displaying the updated information

//creation of tokens
module.exports.loginId = (email1, password1)=>{
    return new Promise((resolve, reject)=>{
        const user =  User.findOne({ email: email1});
        if(user){
             const user1 = User.findOne({ password: password1});
      if(user1)
       { 

        jwt.sign({id:user1._id, email:user1.email},"secretkey", {expiresIn:"50s"},(err,token)=>{
    // res.send({
    //     token
    // });
        
        return resolve({"token":token});
  });
        }
        else {
            reject("Incorrect Password");
        }
        }
        else{
            reject("Email Incorrect")
        }
    });
}