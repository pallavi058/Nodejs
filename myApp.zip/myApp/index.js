const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mongoose = require('mongoose');
const User = require('./model/User');
const route = require('./Routes/UserRouter');

require('dotenv').config();

// app.use(express.bodyParser());
app.get('/', (req, res) => {
    res.send('Basic APIs');
})
app.use(bodyParser.json());
app.use('/api', route);

//copied commented code in Router.js using router.get instead of app.get
/* app.post('/signUp', (req,res) =>{
    console.log(req.body)
    const userData = new User(req.body).save(); //for saving data
    res.send(req.body);
});

app.get('/',async (req, res) => {
 const user =await User.find({});
    res.send(user);
});

app.post('/login', async (req,res) => { //for finding data.
    const email = req.body.email;
    const password = req.body.password; 
    const post = await User.findOne({ "email":email});
    if(post){
         const posto = await User.findOne({ "password":password});
  if(posto)
   { console.log("Successful login");
    res.send("login");
    }
    else {
        console.log("Incorrect Password");
    }
    }
    else{
        console.log("Email Incorrect")
    }
}) */

mongoose.connect(process.env.MONGOD_URL,{useNewUrlParser: true}).then(() => console.log('mongodb is connected'));
// mongoose.plugin(mongoDBErrors)

mongoose.Promise = global.Promise;

app.listen(process.env.PORT, () => {
    console.log('Server works on port ' +process.env.PORT);
});



